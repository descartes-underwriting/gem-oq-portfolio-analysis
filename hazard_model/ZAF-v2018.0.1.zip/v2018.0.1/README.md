This zip file contains the seismic source model and ground motion model for South Africa: ZAF v2018.0.1

The seismic hazard model for South Africa (ZAF) was developed by scientists from the Council for Geoscience, South Africa and the Indian Institute of Technology, Jammu, India. The model is described by Midzi et al. (2019). The model was originally created for the OpenQuake (OQ) engine.

For more information, see https://hazard.openquake.org/gem/models/ZAF/
